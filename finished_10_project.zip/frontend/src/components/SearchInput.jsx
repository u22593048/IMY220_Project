import { useState } from "react";
import PropTypes from "prop-types";

export default function SearchInput({ onSearch,onChange, value }){
  const [q,setQ]=useState("");
  function submit(e){ e.preventDefault(); onSearch?.(q.trim()); }
  return (
    <form className="form flex" onSubmit={submit} role="search" aria-label="Search projects">
       <input name="q" placeholder="Search…" value={value} onChange={(e)=>onChange?.(e.target.value)}/>
      <button className="btn btn-ghost" type="submit">Search</button>
    </form>
  );
}
SearchInput.propTypes={onSearch:PropTypes.func};
