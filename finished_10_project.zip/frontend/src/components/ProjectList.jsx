import PropTypes from "prop-types";
import { useState } from "react";
import ProjectPreview from "./ProjectPreview";

export default function ProjectList({ projects = [], initialLimit = 12 }){
  const [showAll, setShowAll] = useState(false);
  const list = Array.isArray(projects) ? projects : [];
  const visible = showAll ? list : list.slice(0, initialLimit);
  return (
    <div>
      <div className="grid grid-3">
        {visible.map(p => <ProjectPreview key={p._id} project={p} />)}
      </div>
      {projects.length > initialLimit && !showAll && (
        <div className="center mt1">
          <button className="btn" onClick={() => setShowAll(true)}>Show more</button>
        </div>
      )}
    </div>
  );
}
ProjectList.propTypes = { projects: PropTypes.array.isRequired, initialLimit: PropTypes.number };
