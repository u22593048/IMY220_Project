import React, { useState } from 'react';
export default function CreateProjectForm({ onCreate }) {
  const [name,setName]=useState('');
  const [desc,setDesc]=useState('');
  const [type,setType]=useState('');
  const [version,setVersion]=useState('');
  const [hashtags,setHashtags]=useState(''); 
  const [image,setImage]=useState(null);
  const [files,setFiles]=useState([]);

  const nameValid = name.trim().length >= 3;
  const descValid = desc.trim().length >= 10;
  const canSubmit = nameValid && descValid;

  const onDropImage = (e) => { e.preventDefault(); const f=e.dataTransfer.files?.[0]; if (f) setImage(f); };
  const onDropFiles = (e) => { e.preventDefault(); const list=Array.from(e.dataTransfer.files||[]); if (list.length) setFiles(prev=>[...prev,...list]); };

  return (
    <form onSubmit={e=>{
      e.preventDefault();
      if(!canSubmit) return;
   onCreate(
    { name, description: desc, type, version, hashtags },
   { image, files }
  );
    }}>
      <label>Project name
        <input value={name} onChange={e=>setName(e.target.value)} required minLength={3}/>
      </label>

      <label>Type
        <input value={type} onChange={e=>setType(e.target.value)} placeholder="web / mobile / lib"/>
      </label>

      <label>Version
        <input value={version} onChange={e=>setVersion(e.target.value)} placeholder="1.0.0"/>
      </label>

      <label>Hashtags
        <input value={hashtags} onChange={e=>setHashtags(e.target.value)} placeholder="#ai design tools"/>
      </label>

      <label>Description
        <textarea value={desc} onChange={e=>setDesc(e.target.value)} required minLength={10}/>
      </label>

      <div className="card" onDragOver={e=>e.preventDefault()} onDrop={onDropImage}>
        <strong>Cover image (drag & drop or pick)</strong>
        <input type="file" accept="image/*" onChange={e=>setImage(e.target.files?.[0]||null)} />
        {image && <div className="help">{image.name}</div>}
      </div>

      <div className="card" onDragOver={e=>e.preventDefault()} onDrop={onDropFiles}>
        <strong>Project files (drag & drop or pick)</strong>
        <input type="file" multiple onChange={e=>setFiles(prev=>[...prev, ...Array.from(e.target.files||[])])} />
        {files.length>0 && <div className="help">{files.length} file(s) selected</div>}
      </div>

      <button type="submit" disabled={!canSubmit}>Create</button>
    </form>
  );
}
