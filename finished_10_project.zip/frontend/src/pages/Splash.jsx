import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import LoginForm from "../components/Auth/LoginForm";
import SignUpForm from "../components/Auth/SignUpForm";
import backgrounded from "/frontend/public/assets/images/binary-code-475664_640.png";
export default function Splash({ initialTab = "login" }) {
  useEffect(() => {
    const t = localStorage.getItem("token");
    if (t) window.location.assign("/home");
  }, []);
 const [tab, setTab] = useState(initialTab === "signup" ? "signup" : "login");
const pbStyle={
  backgroundImage: `url(${backgrounded})`,
  backgroundAttachment: "fixed",
  backgroundPosition:"center",
  backgroundRepeat:"no-repeat",
  backgroundSize:"cover"
  
};
  return (
  
    <main className="container page splash-hero" style={pbStyle}>
      <section className="card card-pad grid">
        <h1 className="hero-title">CodeControl</h1>
        <p className="hero-sub">Collaborate on code. Share progress. Ship faster.</p>

        <div className="flex mt2">
          <button
            type="button"
            className={`btn ${tab === "login" ? "btn-primary" : ""}`}
            role="tab"
            aria-selected={tab === "login"}
            aria-controls="login-panel"
            id="login-tab"
            onClick={() => setTab("login")}
          >
            Log in
          </button>
          <button type="button" className={`btn ${tab === "signup" ? "btn-primary" : ""}`} role="tab" aria-selected={tab === "signup"} aria-controls="signup-panel" id="signup-tab" onClick={() => setTab("signup")}> Sign up
          </button>
          </div>
        <div className="mt2">
          {tab === "login" ? (
            <section
              id="login-panel"
              role="tabpanel"
              aria-labelledby="login-tab"
              className="grid"
            >
              <h2 className="m0">Welcome back</h2>
              <p className="help">Enter your details to access your account.</p>
              <LoginForm />
            </section>
          ) : (
            <section
              id="signup-panel"
              role="tabpanel"
              aria-labelledby="signup-tab"
              className="grid"
            >
              <h2 className="m0">Create your account</h2>
              <p className="help">Fill in the fields below to get started.</p>
              <SignUpForm />
            </section>
          )}
        </div>

      </section>
    </main>
  );
}
