import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import ProfileCard from "../components/ProfileCard";      
import EditProfileForm from "../components/EditProfileForm"; 
import ProjectList from "../components/ProjectList";
import { Auth, Profile as Api, Projects, Friends } from "../api";

export default function Profile(){
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [err, setErr] = useState("");
const [savedProjects, setSavedProjects] = useState([]);
const [friends, setFriends] = useState([]);
const [uploadErr, setUploadErr] = useState("");
const [uploadBusy, setUploadBusy] = useState(false);
const [relation, setRelation] = useState("public"); // 'self' | 'friend' | 'public' | 'outgoing' | 'incoming'
const [visibility, setVisibility] = useState("public");
useEffect(() => {
  let alive = true;
  (async () => {
    try {
      const data = await Api.get(id === "me" ? "me" : id);
      if (!alive) return;
      setUser(data || null);

      if (id === "me") {
        setRelation("self"); setVisibility("self");
        setProjects(await Projects.listMine());
        setSavedProjects(await Projects.saved(data._id));
        if (Array.isArray(data?.friends)) {
          const details = await Promise.all(
            data.friends.map(fid => Api.get(fid).catch(() => null))
          );
          setFriends(details.filter(Boolean));
        }
        return;
 
      }
       const st = await Friends.status(data._id);
        if (st.relation === "friends") {
        setRelation("friend"); setVisibility("friend");
        if (data?.username) {
          const ps = await Projects.search(data.username);
          setProjects(ps || []);
        }
        if (Array.isArray(data?.friends)) {
          const details = await Promise.all(
            data.friends.map(fid => Api.get(fid).catch(() => null))
          );
          setFriends(details.filter(Boolean));
        }
      } else  {
        setRelation(st.relation === "incoming" ? "incoming" :
        st.relation === "outgoing" ? "outgoing" : "public");
        setVisibility("public");
        setProjects([]); // hide projects
        setFriends([]);
      }
    } catch (e) {
      setErr(e.message || "Failed to load profile");
    }
  })();
  return () => { alive = false; };
}, [id]);


  async function onSave(patch){
    try {
      const sent = {};
      if (patch.name) sent.name = patch.name;
      if (patch.username) sent.username = patch.username; 
      if (patch.bio) sent.bio = patch.bio;
      const updated = await Api.updateMe(sent);
      setUser(updated);
    } catch(e) { setErr(e.message || "Save failed"); }
  }

  async function onDelete(){
    if (!confirm("Delete your profile? This cannot be undone.")) return;
    try { await Api.deleteMe(); localStorage.removeItem("token"); window.location.assign("/signup"); }
    catch(e){ setErr(e.message || "Delete failed"); }
  }
async function onDropAvatar(file){
  try {
    setUploadErr(""); setUploadBusy(true);
    const res = await Api.uploadAvatar(file);
    setUser({ ...user, avatarUrl: res.avatarUrl });
  } catch (e) {
    setUploadErr(e.message || "Upload failed");
  } finally {
    setUploadBusy(false);
  }
}
async function onAddFriend(){
  try {
    await Friends.request(user._id);
    // server returns current relation; we can re-fetch status
    const st = await Friends.status(user._id);
    if (st.relation === "friends") {
      setRelation("friend"); setVisibility("friend");
      // now fetch data we can see as friends
     let ps = [];
  try {
  ps = await Projects.byUser(user._id);
  } catch {}
  if ((!ps || ps.length === 0) && user?.username) {
    try { ps = await Projects.search(user.username); } catch {}
  }
 setProjects(ps || []);
      if (Array.isArray(user?.friends)) {
        const details = await Promise.all(
          user.friends.map(fid => Api.get(fid).catch(() => null))
        );
        setFriends(details.filter(Boolean));
      }
    } else {
      setRelation(st.relation === "incoming" ? "incoming" : "outgoing");
    }
  } catch (e) { /* no-op minimal */ }
}

async function onUnfriend(){
  try {
    await Friends.unfriend(user._id);
    setRelation("public");
    setVisibility("public");
    setProjects([]);
    setFriends([]);
  } catch (e) { /* no-op minimal */ }
}
function onDragOver(e){ e.preventDefault(); }
function onDrop(e){ e.preventDefault(); const f = e.dataTransfer.files?.[0]; if (f) onDropAvatar(f); }
function onPick(e){ const f = e.target.files?.[0]; if (f) onDropAvatar(f); }

  if (!user) return <main className="container page">Loading…</main>;

  return (
    <main className="container page grid grid-2">
      {err && <div className="error">{err}</div>}
      <div className="grid">
        {id === "me" && (
  <section className="card card-pad" onDragOver={onDragOver} onDrop={onDrop}>
    <h3 className="m0">Profile picture</h3>
    <p className="help">Drag & drop an image here, or click to choose a file.</p>
    <input type="file" accept="image/*" onChange={onPick} />
    {uploadBusy ? <div className="help">Uploading…</div> : null}
    {uploadErr ? <div className="error">{uploadErr}</div> : null}
  </section>
)}
        <ProfileCard user={user} visibility={visibility} />
        { (id === "me" || relation === "friend") && (
  <section className="card card-pad" style={{ marginTop: 12 }}>
    <h3 className="m0">{id === "me" ? "My friends" : `${user.name}'s friends`}</h3>
    <ul className="list">
      {friends.map(f => (
        <li key={f._id}>
          <a href={`/profile/${f._id}`}>{f.name}{f.username ? ` @${f.username}` : ""}</a>
        </li>
      ))}
    </ul>
    {friends.length === 0 ? <div className="help">No friends yet.</div> : null}
  </section>
)}
        {}
        {id === "me" && <EditProfileForm user={{ name:user.name, handle:user.username, bio:user.bio||"" }} onSave={onSave}/>}
        {id === "me" &&
          <section className="card card-pad" style={{marginTop:12}}>
            <h3>Danger zone</h3>
            <button className="btn" onClick={onDelete}>Delete my profile</button>
          </section>
        }
      </div>

{ (id === "me" || relation === "friend") && (
  <section className="grid">
    <h2 className="m0">{id === "me" ? "My projects" : `${user.name}'s projects`}</h2>
    <ProjectList projects={projects} />
  </section>
)}
{ id !== "me" && (
  <div className="mt1">
    {relation === "public" && (
      <button className="btn" onClick={onAddFriend}>Add friend</button>
    )}
    {relation === "incoming" && (
      <button className="btn" onClick={onAddFriend}>Accept request</button>
    )}
    {relation === "outgoing" && (
      <button className="btn" disabled>Request sent</button>
    )}
    {relation === "friend" && (
      <button className="btn btn-danger" onClick={onUnfriend}>Unfriend</button>
    )}
  </div>
)}

{/* Saved projects → self only */}
{ id === "me" && (
  <section className="grid">
    <h2 className="m0">Saved projects</h2>
    <ProjectList projects={savedProjects} />
  </section>
)}
    </main>
  );
}
