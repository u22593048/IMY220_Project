import { db, OID } from "../db.js";
export const sendRequest = async (fromUserId, toUserId) => {
  const doc = { fromUserId: OID(fromUserId), toUserId: OID(toUserId), status:"pending", createdAt: new Date() };
  const { insertedId } = await db().collection("friendRequests").insertOne(doc);
  return { ...doc, _id: insertedId };
};
export const setStatus = (id, status) => db().collection("friendRequests")
  .findOneAndUpdate({ _id: OID(id) }, { $set: { status } }, { returnDocument:"after" }).then(r=>r.value);
export const accept = async (id) => {
  const req = await setStatus(id, "accepted");
  if (!req) return null;
  await db().collection("users").updateOne({ _id: req.fromUserId }, { $addToSet: { friends: req.toUserId }});
  await db().collection("users").updateOne({ _id: req.toUserId },   { $addToSet: { friends: req.fromUserId }});
  return req;
};
export const listIncoming = (userId) =>
  db().collection("friendRequests")
    .find({ toUserId: OID(userId), status: "pending" })
    .sort({ createdAt: -1 }).toArray();

export const listOutgoing = (userId) =>
  db().collection("friendRequests")
    .find({ fromUserId: OID(userId), status: "pending" })
    .sort({ createdAt: -1 }).toArray();

export const removeFriend = (a,b) => Promise.all([
  db().collection("users").updateOne({ _id: OID(a) }, { $pull: { friends: OID(b) } }),
  db().collection("users").updateOne({ _id: OID(b) }, { $pull: { friends: OID(a) } })
]);export async function relationBetween(meRaw, otherRaw) {
  const A = OID(String(meRaw));
  const B = OID(String(otherRaw));
  if (String(A) === String(B)) return { relation: "self" }; // robust even if one side is a string

  const d = db();
  const users = d.collection("users");
  const reqs  = d.collection("friendRequests"); // if you embed requests on users, see note below

  const me    = await users.findOne({ _id: A }, { projection: { friends: 1 } });
  const other = await users.findOne({ _id: B }, { projection: { friends: 1 } });
  if (!me || !other) return { relation: "none" };

  const isFriend = Array.isArray(me.friends) && me.friends.map(String).includes(String(B));
  if (isFriend) return { relation: "friends" };

  // Pending requests (two directions) – comment these two blocks out if you do NOT use a friendRequests collection
  const incoming = await reqs.findOne({ fromUserId: B, toUserId: A, status: "pending" }, { projection: { _id: 1 } });
  if (incoming) return { relation: "incoming", requestId: String(incoming._id) };

  const outgoing = await reqs.findOne({ fromUserId: A, toUserId: B, status: "pending" }, { projection: { _id: 1 } });
  if (outgoing) return { relation: "outgoing", requestId: String(outgoing._id) };

  return { relation: "none" };
}
