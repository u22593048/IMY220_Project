
import { db } from "../db.js";
import { ObjectId } from "mongodb";


const projection = { projection: { passwordHash: 0 } };


export async function getUser(idOrUsername) {
  const users = db().collection("users");
  if (typeof idOrUsername === "string" && ObjectId.isValid(idOrUsername)) {
    return await users.findOne({ _id: new ObjectId(idOrUsername) }, projection);
  }
  return await users.findOne({ username: idOrUsername }, projection);
}


export async function getUserByIdOrNull(id) {
  if (!ObjectId.isValid(id)) return null;
  const users = db().collection("users");
  return await users.findOne({ _id: new ObjectId(id) }, projection);
}


export async function getUserByUsername(username) {
  const users = db().collection("users");
  return await users.findOne({ username }, projection);
}
const rxEscape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const editDistance = (a, b) => {
  a = String(a||""); b = String(b||"");
  const m=a.length, n=b.length; if (!m||!n) return Math.max(m,n);
  const dp = Array.from({length:m+1},(_,i)=>Array(n+1).fill(0));
  for (let i=0;i<=m;i++) dp[i][0]=i;
  for (let j=0;j<=n;j++) dp[0][j]=j;
  for (let i=1;i<=m;i++){
    for (let j=1;j<=n;j++){
      const cost = a[i-1]===b[j-1]?0:1;
      dp[i][j] = Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+cost);
    }
  }
  return dp[m][n];
};

export async function searchUsers(rawQ, limit = 20){
  const q0 = String(rawQ||"").trim();
  if (!q0) return [];
  const at = q0.startsWith("@") ? q0.slice(1) : q0;
  const rx = new RegExp(rxEscape(at), "i");

  const Users = db().collection("users");

  let found = await Users.find(
      { $or: [{ username: { $regex: rx } }, { name: { $regex: rx } }] },
      { projection: { _id:1, name:1, username:1, avatarUrl:1 } }
    )
    .limit(limit)
    .toArray();

  if (found.length >= 5 || at.length < 3) return found;

   const candidates = await Users.find(
      {},
      { projection: { _id:1, name:1, username:1, avatarUrl:1 } }
    )
    .limit(200)
    .toArray();

  const fuzz = candidates
    .map(u => {
      const d = Math.min(
        editDistance(at.toLowerCase(), String(u.username||"").toLowerCase()),
        editDistance(at.toLowerCase(), String(u.name||"").toLowerCase())
      );
      return { d, u };
    })
    .filter(x => x.d <= 2)
    .sort((a,b)=>a.d-b.d)
    .slice(0, Math.max(0, limit - found.length))
    .map(x => x.u);

  const byId = new Map();
  [...found, ...fuzz].forEach(u => byId.set(String(u._id), u));
  return Array.from(byId.values()).slice(0, limit);
}

export async function suggestUsers(rawQ, limit = 8){
  const q0 = String(rawQ||"").trim();
  if (!q0) return [];
  const at = q0.startsWith("@") ? q0.slice(1) : q0;

  return db().collection("users")
    .find(
      { $or: [
          { username: { $regex: new RegExp(`^${rxEscape(at)}`, "i") } },
          { name:     { $regex: new RegExp(`^${rxEscape(at)}`, "i") } }
        ] },
      { projection: { _id:1, name:1, username:1, avatarUrl:1 } }
    )
    .limit(limit)
    .toArray();
}