import { Router } from "express";
import { authRequired } from "../auth.js";
import { createProject, getProject, listProjects, updateProject, deleteProject,
         addMember, setCheckout, clearCheckout, searchProjects,listOwnedProjects, listSavedProjects, saveProjectForUser, unsaveProjectForUser,projectFeedGlobal,projectFeedLocal,suggestProjects, setProjectImage,addProjectFiles,removeMember, listVersions, rollbackTo, setOwner } from "../dal/projects.js";
import { addCheckin, listProjectCheckins } from "../dal/checkins.js";
import fs from "fs";
import path from "path";
import multer from "multer";
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = path.join(process.cwd(), "uploads", "projects", String(req.params.id));
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: function (_req, file, cb) {
    const ts = Date.now();
    const safe = file.originalname.replace(/[^\w.\-]+/g, "_");
    cb(null, `${ts}-${safe}`);
  }
});
const upload = multer({ storage });
const r = Router();
r.get("/", authRequired, async (req,res)=> res.json(await listProjects(req.userId)));
r.get("/search", async (req,res)=> res.json(await searchProjects(req.query.q)));
//r.post("/", authRequired, async (req,res)=> res.status(201).json(await createProject({ ownerId:req.userId, ...req.body })));
r.get("/:id", async (req,res)=> res.json(await getProject(req.params.id)));
r.patch("/:id", authRequired, async (req,res)=> res.json(await updateProject(req.params.id, req.body||{})));
r.delete("/:id", authRequired, async (req,res)=> { await deleteProject(req.params.id); res.json({ ok:true }); });
r.post("/:id/members", authRequired, async (req,res)=> { await addMember(req.params.id, req.body.userId); res.json({ ok:true }); });
r.post("/:id/checkout", authRequired, async (req,res)=> { await setCheckout(req.params.id, req.userId); res.json({ ok:true }); });
r.post("/:id/checkin", authRequired, async (req,res)=> res.status(201).json(await addCheckin({ projectId:req.params.id, userId:req.userId, message:req.body.message })));
r.get("/:id/checkins", async (req,res)=> res.json(await listProjectCheckins(req.params.id)));
r.get("/owned/:userId", async (req, res) => {
  res.json(await listOwnedProjects(req.params.userId));
});
r.post("/", authRequired, async (req, res) => {
  const project = await createProject(req.userId, {
    name: req.body.name,
    description: req.body.description,
    hashtags: req.body.hashtags, 
    type: req.body.type,
    version: req.body.version
  });
  res.status(201).json(project);
});
r.post("/:id/owner/:userId", authRequired, async (req,res)=>{
  await setOwner(req.params.id, req.params.userId);
  res.json({ ok:true });
});
r.get("/saved/:userId", async (req, res) => {
  res.json(await listSavedProjects(req.params.userId));
});

r.post("/:id/save", authRequired, async (req, res) => {
  await saveProjectForUser(req.userId, req.params.id);
  res.json({ ok: true });
});

r.delete("/:id/save", authRequired, async (req, res) => {
  await unsaveProjectForUser(req.userId, req.params.id);
  res.json({ ok: true });
});
r.get("/suggest", async (req, res) => {
  res.json(await suggestProjects(req.query.q));
});
r.get("/feed/global", async (_req, res) => {
  res.json(await projectFeedGlobal());
});
r.get("/feed/local", authRequired, async (req, res) => {
  res.json(await projectFeedLocal(req.userId));
  });

r.post("/:id/image", authRequired, upload.single("file"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "file required" });
  const rel = `/uploads/projects/${req.params.id}/${req.file.filename}`;
  res.json(await setProjectImage(req.params.id, rel));
});
r.post("/:id/files", authRequired, upload.array("files", 20), async (req, res) => {
  const files = (req.files || []).map(f => ({
    name: f.originalname,
    url:  `/uploads/projects/${req.params.id}/${f.filename}`,
    size: f.size,
    type: f.mimetype
  }));
  res.json(await addProjectFiles(req.params.id, files, req.userId));
});
r.delete("/:id/members/:userId", authRequired, async (req, res) => {
  await removeMember(req.params.id, req.params.userId);
  res.json({ ok: true });
});
r.get("/:id/versions", authRequired, async (req, res) => {
  res.json(await listVersions(req.params.id));
});

r.post("/:id/rollback/:versionId", authRequired, async (req, res) => {
  const p = await rollbackTo(req.params.id, req.params.versionId);
  if (!p) return res.status(404).json({ error: "Version not found" });
  res.json(p);
});
export default r;
