import { db, OID } from "../db.js";

export async function createProject(a, b) {
  const hasUserId = b !== undefined;
  const userId = hasUserId ? a : b === undefined ? (a?.ownerId) : null;
  const body   = hasUserId ? b : a;
  
const normalizeHashtags = (input, ...alsoFrom) => {
  const raw = Array.isArray(input)
    ? input
    : String(input || "")
        .split(/[ ,]+/)
        .filter(Boolean)
        .map(s => s.replace(/^#/, "").toLowerCase());
  return uniq([...raw, ...alsoFrom.flatMap(extractTags)]);
};
  const name = String(body?.name || "").trim();
  if (!name) throw new Error("name is required");

  const doc = {
    name,
    description: String(body?.description || "").trim(),
    type:        String(body?.type || "").trim(),
    version:     String(body?.version || "").trim(),
    hashtags:    normalizeHashtags(body?.hashtags, body?.name, body?.description),
    ownerId:     OID(userId),               // throws if missing/invalid
    createdAt:   body?.createdAt ? new Date(body.createdAt) : new Date(),
    imageUrl:    body?.imageUrl ?? null,
    files:       Array.isArray(body?.files) ? body.files : [],
    filesCount:  Array.isArray(body?.files) ? body.files.length : 0,
  };

  const Projects = db().collection("projects");
  const { insertedId } = await Projects.insertOne(doc);
  return await Projects.findOne({ _id: insertedId });
}
export const getProject = (id) => db().collection("projects").findOne({ _id: OID(id) });
export const listProjects = (ownerId) => db().collection("projects").find({ ownerId: OID(ownerId) }).toArray();
export const deleteProject = (id) => db().collection("projects").deleteOne({ _id: OID(id) });
export const addMember = (id, userId) => db().collection("projects")
  .updateOne({ _id: OID(id) }, { $addToSet: { memberIds: OID(userId) }, $set: { updatedAt: new Date() } });
export const removeMember = (id, userId) => db().collection("projects")
 .updateOne({ _id: OID(id) }, { $pull: { memberIds: OID(userId) }, $set: { updatedAt: new Date() } });
  export const setCheckout = (id, userId) => db().collection("projects").updateOne({ _id: OID(id) }, { $set: { checkedOutBy: OID(userId) } });
export const clearCheckout = (id) => db().collection("projects").updateOne({ _id: OID(id) }, { $set: { checkedOutBy: null } });
export const setOwner = (id, userId) => db().collection("projects")
  .updateOne({ _id: OID(id) }, { $set: { ownerId: OID(userId), updatedAt: new Date() } });
export const updateProject = async (id, patch) => {
  const Projects = db().collection("projects");
  const Versions = db().collection("projectVersions");
  const _id = OID(id);

  const before = await Projects.findOne({ _id });
  if (before) {
    const { _id: __, ...snapshot } = before;           // drop _id in snapshot
    await Versions.insertOne({ projectId: _id, snapshot, createdAt: new Date() });
  }

  const res = await Projects.findOneAndUpdate(
    { _id },
    { $set: { ...patch, updatedAt: new Date() } },
    { returnDocument: "after" }
  );
  return res.value;
};
export const listVersions = (projectId, limit=20) =>
  db().collection("projectVersions")
    .find({ projectId: OID(projectId) })
    .sort({ createdAt: -1 })
    .limit(limit)
    .toArray();

export const rollbackTo = async (projectId, versionId) => {
  const Versions = db().collection("projectVersions");
  const Projects = db().collection("projects");
  const pid = OID(projectId);
  const vid = OID(versionId);
  const ver = await Versions.findOne({ _id: vid, projectId: pid });
  if (!ver) return null;
  const snap = { ...ver.snapshot };
  delete snap._id; delete snap.createdAt; // never override IDs/timestamps
  await Projects.updateOne({ _id: pid }, { $set: { ...snap, updatedAt: new Date() } });
  return await Projects.findOne({ _id: pid });
};

const rxEscape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const editDistance = (a, b) => {
  a = String(a||""); b = String(b||"");
  const m=a.length, n=b.length; if (!m||!n) return Math.max(m,n);
  const dp = Array.from({length:m+1},(_,i)=>Array(n+1).fill(0));
  for (let i=0;i<=m;i++) dp[i][0]=i;
  for (let j=0;j<=n;j++) dp[0][j]=j;
  for (let i=1;i<=m;i++){
    for (let j=1;j<=n;j++){
      const cost = a[i-1]===b[j-1]?0:1;
      dp[i][j] = Math.min(dp[i-1][j]+1, dp[i][j-1]+1, dp[i-1][j-1]+cost);
    }
  }
  return dp[m][n];
};

export async function suggestProjects(rawQ, limit = 8){
  const q = String(rawQ||"").trim();
  if (!q) return { projects: [], tags: [] };

  const dbo = db();
  const Projects = dbo.collection("projects");

  if (q.startsWith("#")){
    const prefix = q.slice(1);
    const tags = await Projects.aggregate([
      { $unwind: "$hashtags" },
      { $match: { hashtags: { $regex: new RegExp(`^${rxEscape(prefix)}`, "i") } } },
      { $group: { _id: "$hashtags", c: { $sum: 1 } } },
      { $sort: { c: -1, _id: 1 } },
      { $limit: limit }
    ]).toArray();
    return { projects: [], tags: tags.map(t => t._id) };
  }

  const projects = await Projects.find(
      { name: { $regex: new RegExp(`^${rxEscape(q)}`, "i") } },
      { projection: { _id:1, name:1 } }
    ).limit(limit).toArray();

  return { projects, tags: [] };
}
export async function searchProjects(rawQ, limit = 50){
  const q = String(rawQ||"").trim();
  if (!q) return [];

  const dbo = db();
  const Projects = dbo.collection("projects");

  const isTag = q.startsWith("#");
  const tag   = isTag ? q.slice(1) : q;
  const rx    = new RegExp(rxEscape(isTag ? `#${tag}` : tag), "i");


  const filter = isTag
    ? { $or: [
        { name:        { $regex: new RegExp(`\\B#${rxEscape(tag)}\\b`, "i") } },
        { description: { $regex: new RegExp(`\\B#${rxEscape(tag)}\\b`, "i") } },
        { hashtags:    { $in: [tag] } },              
      ] }
    : { $or: [
        { name:        { $regex: rx } },
        { type:        { $regex: rx } },
        { description: { $regex: rx } },
      ] };

  let found = await Projects.find(filter)
    .sort({ createdAt: -1 })
    .limit(limit)
    .toArray();


  if (found.length >= 5 || q.length < 3) return found;

  const candidates = await Projects.find({}, {
      projection: { _id:1, name:1, description:1, createdAt:1 }
    })
    .sort({ createdAt: -1 })
    .limit(200)
    .toArray();

  const fuzz = candidates
    .map(p => {
      const d = Math.min(
        editDistance(q.toLowerCase(), String(p.name||"").toLowerCase()),
        editDistance(q.toLowerCase(), String(p.description||"").toLowerCase())
      );
      return { d, p };
    })
    .filter(x => x.d <= 2)
    .sort((a,b)=>a.d-b.d || (new Date(b.p.createdAt||0)-new Date(a.p.createdAt||0)))
    .slice(0, Math.max(0, limit - found.length))
    .map(x => x.p);


  const byId = new Map();
  [...found, ...fuzz].forEach(p => byId.set(String(p._id), p));
  return Array.from(byId.values()).slice(0, limit);
}
const isValid = (v) => {
  try { OID(v); return true; } catch { return false; }
};

export async function listOwnedProjects(userId) {
  if (!isValid(String(userId))) return [];
const d = db();

const Projects = d.collection("projects");
  return await Projects
    .find({ ownerId: OID(String(userId)) })
    .sort({ updatedAt: -1 })
    .limit(100)
    .toArray();
}

export async function setProjectImage(projectId, imageUrl) {
  const Projects = db().collection("projects");
  await Projects.updateOne(
    { _id: OID(projectId) },
    { $set: { imageUrl } }
  );
  return await Projects.findOne({ _id: OID(projectId) });
}

export async function addProjectFiles(projectId, filesMeta = [], actorUserId = null) {
    if (!Array.isArray(filesMeta) || filesMeta.length === 0) {
    return await db().collection("projects").findOne({ _id: OID(projectId) });
  }
  const Projects = db().collection("projects");
  const stamped = filesMeta.map(f => ({
    ...f,
    uploadedAt: new Date()
  }));
  await Projects.updateOne(
    { _id: OID(projectId) },
    {
      $push: { files: { $each: stamped } },
      $inc: { filesCount: stamped.length }
    }
  );
    if (actorUserId) {
    await db().collection("checkins").insertOne({
      projectId: OID(projectId),
      userId: OID(actorUserId),
      message: `uploaded ${stamped.length} file(s)`,
      createdAt: new Date()
    });
  }
  return await Projects.findOne({ _id: OID(projectId) });
}
export async function listSavedProjects(userId) {
  if (!isValid(String(userId))) return [];
const d = db();
const Users    = d.collection("users");
const Projects = d.collection("projects");
  const u = await Users.findOne(
    { _id: OID(String(userId)) },
    { projection: { savedProjectIds: 1 } }
  );
  const ids = (u?.savedProjectIds || []).map(id => new OID(String(id)));
  if (!ids.length) return [];
  return await Projects
    .find({ _id: { $in: ids } })
    .sort({ updatedAt: -1 })
    .limit(100)
    .toArray();
}


export async function saveProjectForUser(userId, projectId) {
  if (!isValid(String(userId)) || !isValid(String(projectId))) return;
const d = db();
const Users    = d.collection("users");

  await Users.updateOne(
    { _id: OID(String(userId)) },
    { $addToSet: { savedProjectIds: OID(String(projectId)) } }
  );
}


export async function unsaveProjectForUser(userId, projectId) {
  if (!isValid(String(userId)) || !isValid(String(projectId))) return;
const d = db();
const Users    = d.collection("users");

  await Users.updateOne(
    { _id: OID(String(userId)) },
    { $pull: { savedProjectIds: OID(String(projectId)) } }
  );
}

export async function projectFeedGlobal(limit = 100) {
  return db().collection("projects")
    .find({})
    .sort({ createdAt: -1 })
    .limit(limit)
    .toArray();
}

export async function projectFeedLocal(userId, limit = 100) {
  const dbo = db();
  const Users = dbo.collection("users");
  const Projects = dbo.collection("projects");


  const me = await Users.findOne(
    { _id: OID(String(userId)) },
    { projection: { friends: 1 } }
  );
  const friendIds = Array.isArray(me?.friends)
    ? me.friends.map(id => OID(String(id)))
    : [];


  const ownerIds = [OID(String(userId)), ...friendIds];
  const created = await Projects
    .find({ ownerId: { $in: ownerIds } })
    .sort({ createdAt: -1 })
    .limit(limit * 2)
    .toArray();


  const savedLists = await Promise.all(friendIds.map(fid =>
    listSavedProjects(fid).catch(() => [])
  ));
  const saved = savedLists.flat();


  const byId = new Map();
  for (const p of [...created, ...saved]) byId.set(String(p._id), p);
  return Array.from(byId.values())
    .sort((a, b) => new Date(b.createdAt ?? 0) - new Date(a.createdAt ?? 0))
    .slice(0, limit);
}
