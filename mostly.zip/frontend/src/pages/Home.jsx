import React, { useEffect, useState } from "react";
import SearchInput from "../components/SearchInput"; 
import ProjectList from "../components/ProjectList";
import CreateProjectForm from "../components/CreateProjectForm";
import { Projects, Profile as Api, Search} from "../api";

export default function Home(){
  const [projects, setProjects] = useState([]);
  const [all, setAll] = useState([]);
  const [err, setErr] = useState("");
  const [localFeed, setLocalFeed] = useState([]);
  const [globalFeed, setGlobalFeed] = useState([]);
  const [scope, setScope] = useState("local"); // 'local' | 'global'
  const [users, setUsers] = useState([]);
  const [q, setQ] = useState("");
  const [suggest, setSuggest] = useState({ users: [], projects: [], tags: [] });
  const [showSug, setShowSug] = useState(false);
  let debounceId;

  function debounce(fn, ms=180){
    clearTimeout(debounceId);
   debounceId = setTimeout(fn, ms);
 }
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
          const [locRaw, globRaw] = await Promise.all([
          Projects.feedLocal().catch(()=>[]),
          Projects.feedGlobal().catch(()=>[]),
        ]);
        if (!alive) return;
        const asArr = (x) =>
        Array.isArray(x) ? x
        : Array.isArray(x?.data) ? x.data
        : Array.isArray(x?.items) ? x.items
        : [];
      const loc = asArr(locRaw);
      const glob = asArr(globRaw);
      setLocalFeed(loc);
      setGlobalFeed(glob);
      setAll(loc);
      setProjects(loc);
      } catch (e) {
        setErr(e.message || "Failed to load projects");
      }
    })();
    return () => { alive = false; };
  }, []);

  async function onSearch(q){
    const term = (q||"").trim();
    if (!term) { setUsers([]); return setProjects(all); }
    const source = Array.isArray(scope === "local" ? localFeed : globalFeed) ? (scope === "local" ? localFeed : globalFeed) : [];
    const s = term.toLowerCase();
   setProjects(source.filter(p =>
      (p.name||"").toLowerCase().includes(s) ||
      (p.description||"").toLowerCase().includes(s) ||
      (p.hashtags||[]).some(t => String(t).toLowerCase().includes(s.replace(/^#/, "")))
    ));

    try { setUsers(await Api.search(term)); } catch { setUsers([]); }
  }
  async function onChangeInput(val){
    setQ(val);
    if (!val.trim()) { setSuggest({users:[],projects:[],tags:[]}); setShowSug(false); return; }
    debounce(async ()=>{
      try{
        if (val.startsWith("#")){
          const s = await Projects.suggest(val);
          setSuggest({ users: [], projects: [], tags: s.tags||[] });
        } else {
         const [su, sp] = await Promise.all([
            Profile.suggest(val), Projects.suggest(val)
          ]);
          setSuggest({ users: su||[], projects: (sp?.projects)||[], tags: (sp?.tags)||[] });
        }
       setShowSug(true);
     }catch{ setShowSug(false); }
   });
 }
 async function createAndAttach(body, assets){
    const p = await Projects.create(body);
    let updated = p;
    if (assets?.image) {
      const r = await Projects.uploadImage(p._id, assets.image);
      updated = { ...updated, imageUrl: r.imageUrl };
    }
    if (assets?.files?.length) {
      const r = await Projects.uploadFiles(p._id, assets.files);
      updated = { ...updated, files: r.files, filesCount: r.filesCount };
    }
    setProjects([updated, ...(Array.isArray(projects)?projects:[])]);
    setAll([updated, ...(Array.isArray(all)?all:[])]);
  }

  return (
    <main className="container page grid">
      <section className="card card-pad">
        <div className="flex between center">
          <h2 className="m0">Create project</h2>
          <div className="btn-group">
            <button className={`btn ${scope==='local'?'btn-primary':''}`} onClick={() => { setScope('local'); setAll(localFeed); setProjects(localFeed); }}>Local</button>
            <button className={`btn ${scope==='global'?'btn-primary':''}`} onClick={() => { setScope('global'); setAll(globalFeed); setProjects(globalFeed); }}>Global</button>
          </div>
        </div>
        <CreateProjectForm onCreate={createAndAttach}/>
      </section>
{users.length > 0 && (
        <section className="card card-pad">
          <h3 className="m0">Users</h3>
          <ul className="list">
            {users.map(u => (
              <li key={u._id}>
                <a href={`/profile/${u._id}`}>{u.name}{u.username ? ` @${u.username}` : ""}</a>
              </li>
            ))}
          </ul>
        </section>
      )}
      <section className="card card-pad">
        <div style={{ position:"relative" }}>
    <SearchInput onSearch={onSearch} onChange={onChangeInput} value={q}/>
    {showSug && (
      <div className="dropdown">
        {suggest.tags.length>0 && (
          <div className="dropdown-group">
            <div className="muted">Tags</div>
            {suggest.tags.map(t => (
              <div key={t} className="item" onMouseDown={()=>{ setQ(`#${t}`); onSearch(`#${t}`); }}>
                #{t}
              </div>
            ))}
          </div>
        )}
        {suggest.users.length>0 && (
          <div className="dropdown-group">
            <div className="muted">Users</div>
            {suggest.users.map(u => (
              <a key={u._id} className="item" href={`/profile/${u._id}`}>
                {u.name}{u.username?` @${u.username}`:""}
              </a>
            ))}
          </div>
        )}
        {suggest.projects.length>0 && (
          <div className="dropdown-group">
            <div className="muted">Projects</div>
            {suggest.projects.map(p => (
              <div key={p._id} className="item" onMouseDown={()=>{ setQ(p.name); onSearch(p.name); }}>
                {p.name}
              </div>
            ))}
          </div>
        )}
      </div>
    )}
  </div>  </section>

      {err && <div className="error">{err}</div>}

      <ProjectList projects={projects}/>
    </main>
  );
}
