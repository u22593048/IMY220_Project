import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import ProjectView from "../components/ProjectView";       
import EditProjectForm from "../components/EditProjectForm"; 
import FilesList from "../components/FilesList";
import MessagesList from "../components/MessagesList";     
import { Projects } from "../api";
import { useAuth } from "../hooks/useAuth"; // if you need current user id


export default function Project(){
  const [checkinText, setCheckinText] = useState("");
  const { id } = useParams();
  const { user } = {}
  const [project, setProject] = useState(null);
  const [checkins, setCheckins] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [versions, setVersions] = useState([]);
  async function loadVersions(){ try { setVersions(await Projects.versions(id)); } catch(e){} }
  async function refresh(){
    try {
      const [p, c] = await Promise.all([Projects.get(id), Projects.checkins(id)]);
      setProject(p ? { ...p, tags: p.hashtags || [] } : null); 
      setCheckins(c || []);
       await loadVersions();
    } catch (e) {
      setErr(e.message || "Failed to load project");
    }
  }

  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [id]);

  async function onUploadFiles(files){
    await Projects.uploadFiles(id, files);
    await refresh();
  }
  async function onUploadImage(file){
    await Projects.uploadImage(id, file);
    await refresh();
  }
  //todo
  async function onCheckout() {
 await Projects.checkout(id);
    await refresh();
  }

 async function onCheckin(text){
   const t = String(text||"").trim();
   if (!t) return;
   await Projects.checkin(id, t);
   setCheckinText("");
   await refresh();
}

  async function onSave(patch){
    try {
      const sent = { ...patch };
      if (Array.isArray(patch.tags)) sent.hashtags = patch.tags;
      delete sent.tags;
      await Projects.update(id, sent);
      await refresh();
    } catch (e) {
      setErr(e.message || "Save failed");
    }
  }
  async function onDelete(){
    if (!confirm("Delete this project?")) return;
    try { await Projects.remove(id); window.location.assign("/home"); }
    catch(e){ setErr(e.message || "Delete failed"); }
  }

  if (!project) return <main className="container page">Loading…</main>;

  return (
    <main className="container page grid">
      {err && <div className="error">{err}</div>}

      <section className="card card-pad">
        <div className="flex between center">
          <h1 className="m0">{project.name}</h1>
          <div className="row gap">
            <button className="btn" onClick={onCheckout} disabled={busy}>Check out</button>
            <button className="btn" onClick={onDelete}>Delete</button>
          </div>
        </div>
        {project.description && <p className="help">{project.description}</p>}
      </section>

      <section className="card card-pad">
        <h3>Check in</h3>
        <form className="row gap" onSubmit={onCheckin}>
 <input placeholder="What did you do?"
        value={checkinText}
        onChange={e=>setCheckinText(e.target.value)} />
 <button onClick={()=>onCheckin(checkinText)}>Check in</button>
        </form>
      </section>

      <section>
        <ProjectView project={project}/>
      </section>
<section className="card card-pad flex between center">
        <div>
          <strong>Status: </strong>
          {project?.checkedOutBy ? "Checked out" : "Available"}
        </div>
        <div className="flex gap">
          {!project?.checkedOutBy && <button className="btn" onClick={onCheckout}>Check out</button>}
        </div>
      </section>

      <section className="card card-pad">
        <h3>Cover Image</h3>
       {project?.imageUrl && <img src={project.imageUrl} alt="" style={{maxWidth:240}}/>}
        <div>
          <input type="file" accept="image/*" onChange={e=>e.target.files?.[0] && onUploadImage(e.target.files[0])}/>
        </div>
      </section>

 <FilesList files={project?.files||[]} onUpload={onUploadFiles} />
<section className="card card-pad">
  <h3 className="m0">Members</h3>
  <ul className="list">
    {(project?.memberIds||[]).map(uid => (
      <li key={uid} className="flex between center">
        <a href={`/profile/${uid}`}>{uid}</a>
        <span className="flex gap">
          <button className="btn btn-ghost" onClick={async()=>{
            await Projects.removeMember(project._id, uid);
            await refresh();
          }}>Remove</button>
          <button className="btn btn-ghost" onClick={async()=>{
            await Projects.setOwner(project._id, uid);
            await refresh();
          }}>Make owner</button>
        </span>
      </li>
    ))}
  </ul>
</section>
      <section className="card card-pad">
        <h3>Activity</h3>
        <ul className="list">
          {checkins.map(ci => (
    <li key={ci._id} className="flex between">
      <span>{ci.message}</span>
      <span className="muted">{ci.createdAt ? new Date(ci.createdAt).toLocaleString() : ""}</span>
    </li>
  ))}  </ul>
      </section>

      <section>
        <MessagesList messages={checkins} onSend={(m)=>onCheckin(m?.text ?? m)} />
        <EditProjectForm project={project} onSave={onSave}/>
      </section>
      <section className="card card-pad">
  <h3 className="m0">Version history</h3>
  <ul className="list">
    {versions.map(v => (
      <li key={v._id} className="flex between center">
        <span>{new Date(v.createdAt).toLocaleString()}</span>
        <button className="btn btn-ghost" onClick={async()=>{
          await Projects.rollback(id, v._id);
          await refresh();
        }}>Rollback</button>
      </li>
    ))}
  </ul>
</section>
    </main>
  );
}
