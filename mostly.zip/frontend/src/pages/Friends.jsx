import React, { useEffect, useState } from "react";
import { Friends as Api, Profile } from "../api";

export default function FriendsPage(){
  const [err,setErr] = useState("");
  const [busy,setBusy] = useState(false);
  const [username,setUsername] = useState("");
  const [incoming, setIncoming] = useState([]);
  const [outgoing, setOutgoing] = useState([]);

  async function load(){ 
    try{
      const [inc, out] = await Promise.all([Api.incoming(), Api.outgoing()]);
      setIncoming(inc||[]); setOutgoing(out||[]);
    }catch(e){ setErr(e.message||"Failed to load requests"); }
  }
  useEffect(()=>{ load(); },[]);

  async function send(){
    if(!username.trim()) return;
    setBusy(true); setErr("");
    try{
      const hits = await Profile.search(username.trim());
      const u = (hits||[]).find(x => x.username?.toLowerCase() === username.trim().toLowerCase());
      if(!u) throw new Error("User not found");
      await Api.send(u._id);
      setUsername("");
      await load();
      alert("Request sent.");
    }catch(e){ setErr(e.message || "Failed"); }
    finally{ setBusy(false); }
  }

  return (
    <main className="container page grid">
      <section className="card card-pad">
        <h2>Add friend</h2>
        <div className="row gap">
          <input className="input" placeholder="Username"
                 value={username} onChange={e=>setUsername(e.target.value)}/>
          <button className="btn" onClick={send} disabled={busy}>Send</button>
        </div>
        {err && <div className="help mt1">{err}</div>}
      </section>

      <section className="card card-pad grid">
        <h3 className="m0">Incoming requests</h3>
        <ul className="list">
          {incoming.length===0 && <li className="muted">No incoming requests.</li>}
          {incoming.map(r => (
            <li key={r._id} className="flex between center">
              <span><strong>{r.fromUserId}</strong> → you • {new Date(r.createdAt).toLocaleString()}</span>
              <span className="flex gap">
                <button className="btn" onClick={async()=>{ await Api.accept(r._id); await load(); }}>Accept</button>
                <button className="btn btn-ghost" onClick={async()=>{ await Api.reject(r._id); await load(); }}>Reject</button>
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card card-pad grid">
        <h3 className="m0">Outgoing requests</h3>
        <ul className="list">
          {outgoing.length===0 && <li className="muted">No outgoing requests.</li>}
          {outgoing.map(r => (
            <li key={r._id} className="flex between center">
              <span>you → <strong>{r.toUserId}</strong> • {new Date(r.createdAt).toLocaleString()}</span>
              <button className="btn btn-ghost" onClick={async()=>{ await Api.reject(r._id); await load(); }}>
                Cancel
              </button>
            </li>
          ))}
        </ul>
      </section>

      {}
      {}
    </main>
  );
}
