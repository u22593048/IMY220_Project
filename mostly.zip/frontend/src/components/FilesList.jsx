export default function FilesList({ files=[], onUpload, onRemove }){
  const list = Array.isArray(files) ? files : [];
  const onDrop = (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files||[]);
    if (dropped.length && onUpload) onUpload(dropped);
  };
  return (
    <section className="card card-pad grid" onDragOver={e=>e.preventDefault()} onDrop={onDrop}>
      <h3 className="m0">Files</h3>
      <ul className="list mt1">
        {list.length === 0 && <li className="muted">No files yet.</li>}
        {list.map(f => (
          <li key={f.url||f.name} className="flex between center">
            <a href={f.url} target="_blank" rel="noreferrer" download>{f.name}</a>
            <span className="muted">{f.size ? Math.round(f.size/1024) + " KB" : ""}</span>
            {onRemove && <button className="btn btn-ghost" onClick={()=>onRemove(f)}>Remove</button>}
          </li>
        ))}
      </ul>
      <div className="mt1">
        <button type="button" className="btn" onClick={()=>{
          const input=document.createElement("input");
          input.type="file"; input.multiple=true;
          input.onchange=()=>onUpload && onUpload(Array.from(input.files||[]));
          input.click();
        }}>Upload…</button>
      </div>
    </section>
  );
}
