import { useState } from "react";
import PropTypes from "prop-types";

export default function MessagesList({ messages=[], onSend }){
  const [text, setText] = useState("");
  const valid = text.trim().length >= 2;

  function send(e){
    e.preventDefault();
    if (!valid) return;
    onSend?.(text.trim());
    setText("");
  }

  return (
    <section className="card card-pad grid">
      <h3 className="m0">Activity</h3>
      <ul className="list mt1">
        {messages.map(m => {
          const msg = m.message ?? m.text ?? "";
          const at  = m.createdAt ?? m.at;
          const when = at ? new Date(at).toLocaleString() : "";
          return (
            <li key={m._id || when+msg} className="flex between">
              <span>{msg}</span>
              <span className="muted">{when}</span>
            </li>
          );
        })}
      </ul>

      <form className="form mt2" onSubmit={send}>
        <label className="label" htmlFor="msg">Check-in message</label>
        <input id="msg"
               className={`input ${!valid && text ? "is-invalid" : ""}`}
               placeholder="What did you do?"
               value={text}
               onChange={e=>setText(e.target.value)}/>
        <div className="flex gap">
          <button className="btn btn-primary" type="submit" disabled={!valid}>Post</button>
          <span className="help">Minimum 2 characters.</span>
        </div>
      </form>
    </section>
  );
}
MessagesList.propTypes = { messages: PropTypes.array, onSend: PropTypes.func };
