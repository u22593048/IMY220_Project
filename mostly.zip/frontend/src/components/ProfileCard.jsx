import PropTypes from "prop-types";

export default function ProfileCard({ user }){
  const placeholders = [
    //remember to add/change
    "/assets/images/codecontrol-logo.png",
    "/assets/images/binary-code-475664_640.webp",
    "/assets/images/binary-code-475664_640.png"
  ];
  const avatarSrc = (user.avatarUrl || user.avatar)
    ?? placeholders[((user.username || user.handle || "x").length) % placeholders.length];
  const handle = user.username || user.handle;

  return (
    <aside className="card card-pad">
      <div className="flex center">
        <img className="avatar" src={avatarSrc} alt="" />
        <div>
          <h3 className="m0">{user.name}</h3>
          <div className="help">@{handle}</div>
        </div>
      </div>
      <div className="badges mt2">
        <span className="badge">{user.projectsCount ?? 0} projects</span>
        <span className="badge">{(user.friends?.length) ?? user.friendsCount ?? 0} friends</span>
      </div>
      {user.bio ? <p className="mt1">{user.bio}</p> : null}
    </aside>
  );
}
ProfileCard.propTypes = {
  user: PropTypes.shape({
    name: PropTypes.string.isRequired,
    username: PropTypes.string,
    handle: PropTypes.string,
    avatarUrl: PropTypes.string,
    avatar: PropTypes.string,
    bio: PropTypes.string,
    friends: PropTypes.array
    
  }).isRequired,
  visibility: PropTypes.oneOf(["public","friend","self"])
};
