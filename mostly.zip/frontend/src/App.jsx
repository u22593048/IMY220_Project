import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Splash from "./pages/Splash";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Home from "./pages/Home";
import Profile from "./pages/Profile";
import Project from "./pages/Project";
import Friends from "./pages/Friends";
import Search from "./pages/Search";
import ProtectedRoute from "./components/ProtectedRoute";
export default function App(){
  return (
    <>
      <Header/>
      <Routes>
        <Route path="/" element={<Splash/>}/>
        <Route path="/login" element={<ProtectedRoute><Login /></ProtectedRoute>} />
        <Route path="/signup" element={<ProtectedRoute><Signup /></ProtectedRoute>} />
        <Route path="/home" element={<ProtectedRoute><Home/></ProtectedRoute>}/>
        <Route path="/profile/:id" element={<ProtectedRoute><Profile/></ProtectedRoute>}/>
        <Route path="/project/:id" element={<ProtectedRoute><Project/></ProtectedRoute>}/>
        <Route path="*" element={<ProtectedRoute><main className="container page"><h2>404 Not Found</h2></main></ProtectedRoute>} />
        <Route path="/friends" element={<ProtectedRoute><Friends/></ProtectedRoute>}/>
        <Route path="/search" element={<ProtectedRoute><Search/></ProtectedRoute>}/>
        
      </Routes>
    </>
  );
}
